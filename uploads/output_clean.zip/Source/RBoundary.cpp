#include "stdafx.h"
#include "RBoundary.h"

RBoundary::RBoundary(void)
{
}

RBoundary::~RBoundary(void)
{
}