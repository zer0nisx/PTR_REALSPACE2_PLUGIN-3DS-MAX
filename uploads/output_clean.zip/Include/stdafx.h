#ifndef _STDAFX_H
#define _STDAFX_H

#if _MSC_VER > 1000
#pragma once
#endif

#include <winsock2.h>
#include <crtdbg.h>
#include <mbstring.h>
#include <tchar.h>

#include <list>
#include <vector>
#include <map>
#include <string>
#include <list>

#include "d3dx9math.h"

#include "MDebug.h"
#include "MZFileSystem.h"
#include "fileinfo.h"
#include "MXml.h"
#include "RTypes.h"
#include "RMesh.h"

#endif