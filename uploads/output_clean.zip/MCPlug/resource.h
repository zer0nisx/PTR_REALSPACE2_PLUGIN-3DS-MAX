//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MCplug2.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_EXP                         1
#define IDS_CATEGORY                    2
#define IDS_CLASS_NAME                  3
#define IDS_PARAMS                      4
#define IDS_SPIN                        5
#define IDS_EXTENSION1                  6
#define IDS_LONGDESC                    7
#define IDS_SHORTDESC                   8
#define IDS_COPYRIGHT                   9
#define IDS_PROGRESS_MSG                10
#define IDS_VERSIONSTRING               11
#define IDD_PANEL                       101
#define IDD_ELU_EXPORT                  105
#define IDC_CLOSEBUTTON                 1000
#define IDC_DOSTUFF                     1000
#define IDC_DEBUG_TEXT_OUT              1021
#define IDC_MESH_OUT                    1022
#define IDC_ANI_OUT                     1023
#define IDC_DEBUG_BIP_MESH_OUT          1024
#define IDC_COLOR                       1456
#define IDC_VERTEX_ANI_OUT              1456
#define IDC_TM_ANI_OUT                  1457
#define IDC_EDIT                        1490
#define IDC_SPIN                        1496

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
